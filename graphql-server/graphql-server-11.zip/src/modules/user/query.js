import { MockDdata } from '../../lib/MockData';
import { validateEmail } from '../../utils/validation';

const Query = {
    getUser: (_, {/*  trainee, reviewer  */}, { }) => {
        try {
            return {
                message: "success",
                status: 200,
                data: MockDdata,
            }
        } catch (err) {
            console.log('---error---', err);
            return {
                message: err.message,
            }
                ;
        }
    },
    getUserRole: (_, { email, role }, { }) => {
        try {
            console.log("sriya,=====", email, role);
            console.log("validateUser(email)", validateEmail(email));
            if (!validateEmail(email)) {
                // console.log('----message--', JSON.stringify());
                throw new Error("Email is not valid" );
            } 
                return {
                    message: "success",
                    status: 200,
                    Roledata: [{
                        email: email,
                        role: role,
                    }],
                }
            
        } catch (error) {
            console.log('----user role--', error);
            return error;

        }
    }
}

export default Query;
// console.log('-------hhgghhgghghghgh-----------------');

    // testApollo: () => {
    //     console.log('===in====')
    //     return "Apollo server setup"
    // },
