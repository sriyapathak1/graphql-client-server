// getuser:  {       }
userRole = {
all: [head-trainee],
read: ['trainee', 'trainer'],
write: [ 'trainee' ],
delete:[ ]
}

const userPermission = () => {
    
}