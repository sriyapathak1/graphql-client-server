require('@babel/polyfill');
require('@babel/register');
require('./src/index');
